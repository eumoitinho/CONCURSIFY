import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { createServerSupabaseClient } from '@/lib/supabase'
import { generateSimuladoReport, SimuladoReportData } from '@/lib/reports/simulado-report'
import { checkFeatureAccess } from '@/lib/middleware/subscription-check'
import { readFile } from 'fs/promises'
import path from 'path'

const supabase = createServerSupabaseClient()

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Não autenticado' },
        { status: 401 }
      )
    }

    // Verificar acesso à feature de relatórios
    const accessCheck = await checkFeatureAccess(session.user.id, 'reports')
    if (!accessCheck.allowed) {
      return NextResponse.json({
        error: accessCheck.error,
        requiresUpgrade: accessCheck.upgradeRequired
      }, { status: 403 })
    }

    const { type = 'pdf' } = await req.json()
    
    // Buscar dados do simulado
    const { data: simulado, error: simuladoError } = await supabase
      .from('simulados')
      .select('*')
      .eq('id', params.id)
      .eq('user_id', session.user.id)
      .single()

    if (simuladoError || !simulado) {
      return NextResponse.json(
        { error: 'Simulado não encontrado' },
        { status: 404 }
      )
    }

    if (simulado.status !== 'finalizado') {
      return NextResponse.json(
        { error: 'Simulado ainda não foi finalizado' },
        { status: 400 }
      )
    }

    // Buscar respostas e dados das questões
    const { data: respostas, error: respostasError } = await supabase
      .from('simulado_respostas')
      .select(`
        *,
        questoes!inner(
          id,
          texto,
          alternativas,
          resposta_correta,
          explicacao,
          materia,
          assunto,
          nivel_dificuldade
        )
      `)
      .eq('simulado_id', params.id)

    if (respostasError || !respostas) {
      return NextResponse.json(
        { error: 'Erro ao carregar respostas do simulado' },
        { status: 500 }
      )
    }

    // Buscar dados do usuário
    const { data: usuario, error: usuarioError } = await supabase
      .from('profiles')
      .select('full_name, email, subscription_plan')
      .eq('id', session.user.id)
      .single()

    if (usuarioError) {
      return NextResponse.json(
        { error: 'Erro ao carregar dados do usuário' },
        { status: 500 }
      )
    }

    // Calcular feedback básico (simulação - em produção viria do banco)
    const acertos = respostas.filter(r => r.is_correct).length
    const pontuacaoGeral = (acertos / respostas.length) * 100

    // Calcular performance por matéria
    const performancePorMateria: Record<string, { acertos: number; total: number; percentual: number }> = {}
    
    respostas.forEach(resposta => {
      const materia = resposta.questoes.materia
      if (!performancePorMateria[materia]) {
        performancePorMateria[materia] = { acertos: 0, total: 0, percentual: 0 }
      }
      performancePorMateria[materia].total++
      if (resposta.is_correct) {
        performancePorMateria[materia].acertos++
      }
    })

    Object.keys(performancePorMateria).forEach(materia => {
      const stats = performancePorMateria[materia]
      stats.percentual = (stats.acertos / stats.total) * 100
    })

    // Preparar dados para o relatório
    const reportData: SimuladoReportData = {
      simulado: {
        id: simulado.id,
        titulo: simulado.titulo,
        configuracao: simulado.configuracao,
        pontuacao: simulado.pontuacao || pontuacaoGeral,
        tempo_total: simulado.tempo_fim 
          ? Math.round((new Date(simulado.tempo_fim).getTime() - new Date(simulado.tempo_inicio).getTime()) / (1000 * 60))
          : 0,
        data_realizacao: simulado.tempo_fim || simulado.created_at
      },
      respostas: respostas.map(r => ({
        questao_id: r.questao_id,
        questao_texto: r.questoes.texto,
        resposta_usuario: r.resposta_usuario,
        resposta_correta: r.resposta_correta,
        is_correct: r.is_correct,
        tempo_resposta: r.tempo_resposta,
        materia: r.questoes.materia,
        assunto: r.questoes.assunto,
        explicacao: r.questoes.explicacao
      })),
      feedback: {
        pontuacao_geral: pontuacaoGeral,
        pontuacao_por_materia: performancePorMateria,
        pontos_fortes: generatePontosFortes(performancePorMateria),
        pontos_fracos: generatePontosFracos(performancePorMateria),
        recomendacoes: generateRecomendacoes(performancePorMateria, pontuacaoGeral),
        tempo_medio_por_questao: reportData?.simulado.tempo_total ? (reportData.simulado.tempo_total * 60) / respostas.length : 120,
        questoes_mais_demoradas: respostas
          .sort((a, b) => b.tempo_resposta - a.tempo_resposta)
          .slice(0, 3)
          .map(r => ({
            questao_id: r.questao_id,
            tempo: r.tempo_resposta,
            materia: r.questoes.materia
          })),
        nivel_sugerido: pontuacaoGeral >= 70 ? 'dificil' : pontuacaoGeral >= 50 ? 'medio' : 'facil',
        plano_estudo_sugerido: {
          materias_prioritarias: Object.entries(performancePorMateria)
            .filter(([, stats]) => stats.percentual < 60)
            .map(([materia]) => materia)
            .slice(0, 3),
          tempo_sugerido_por_materia: {},
          proximos_assuntos: []
        }
      },
      usuario: {
        nome: usuario.full_name || 'Usuário',
        email: usuario.email || '',
        plano: usuario.subscription_plan || 'free'
      }
    }

    if (type === 'pdf') {
      // Gerar PDF
      const pdfPath = await generateSimuladoReport(reportData, '/tmp')
      
      // Ler arquivo PDF
      const pdfBuffer = await readFile(pdfPath)
      
      // Retornar PDF como response
      return new NextResponse(pdfBuffer, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="simulado-${params.id}-relatorio.pdf"`,
          'Content-Length': pdfBuffer.length.toString(),
        },
      })
    } else {
      // Retornar dados JSON para relatório web
      return NextResponse.json({
        success: true,
        data: reportData
      })
    }

  } catch (error) {
    console.error('Erro ao gerar relatório:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

// Funções auxiliares para gerar insights
function generatePontosFortes(performance: Record<string, { percentual: number }>): string[] {
  const fortes = Object.entries(performance)
    .filter(([, stats]) => stats.percentual >= 70)
    .map(([materia]) => `Bom desempenho em ${materia}`)
  
  return fortes.length > 0 ? fortes : ['Determinação para estudar']
}

function generatePontosFracos(performance: Record<string, { percentual: number }>): string[] {
  const fracos = Object.entries(performance)
    .filter(([, stats]) => stats.percentual < 50)
    .map(([materia]) => `Necessita reforço em ${materia}`)
  
  return fracos.length > 0 ? fracos : ['Continue praticando regularmente']
}

function generateRecomendacoes(
  performance: Record<string, { percentual: number }>, 
  pontuacaoGeral: number
): string[] {
  const recomendacoes = []
  
  if (pontuacaoGeral < 50) {
    recomendacoes.push('Revise os conceitos fundamentais das matérias')
    recomendacoes.push('Pratique mais questões básicas antes de avançar')
  } else if (pontuacaoGeral < 70) {
    recomendacoes.push('Foque nas matérias com menor aproveitamento')
    recomendacoes.push('Aumente gradualmente a dificuldade das questões')
  } else {
    recomendacoes.push('Mantenha a consistência nos estudos')
    recomendacoes.push('Pratique questões mais avançadas para consolidar o conhecimento')
  }
  
  const materiasFracas = Object.entries(performance)
    .filter(([, stats]) => stats.percentual < 60)
    .slice(0, 2)
  
  materiasFracas.forEach(([materia]) => {
    recomendacoes.push(`Dedique mais tempo aos estudos de ${materia}`)
  })
  
  return recomendacoes.slice(0, 5)
}